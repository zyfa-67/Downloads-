package app.misterdm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.concurrent.Callable
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

const val RUNNING = 1
const val PAUSED = 2
const val DONE = 3
const val FAILED = 4
const val SAVING = 5

/** Satu potongan (koneksi) file: byte start..end. [done] = byte yang sudah terunduh. end < 0 = ukuran tidak diketahui. */
class Seg(val start: Long, val end: Long, d: Long = 0L) {
    @Volatile var done = d
    val fin: Boolean get() = end >= 0 && start + done > end
}

class Task(val id: Long, val url: String, @Volatile var name: String, val conns: Int) {
    @Volatile var total = -1L
    @Volatile var status = PAUSED
    @Volatile var speed = 0L
    @Volatile var stop = false
    @Volatile var fail = false
    @Volatile var busy = false
    @Volatile var again = false
    @Volatile var removed = false
    @Volatile var ranged = false
    @Volatile var err = ""
    @Volatile var uri = ""
    @Volatile var segs: List<Seg> = emptyList()
    val tick = AtomicLong()
    val links = CopyOnWriteArrayList<HttpURLConnection>()
    val done: Long get() = segs.sumOf { it.done }
}

/** Mesin unduh: multi-koneksi (HTTP Range), jeda/lanjut, simpan status, hasil dipindah ke Download/MisterDM. */
object Engine {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) MisterDM/1.0"
    private const val CH = "dl"
    private lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var nm: NotificationManager
    private val pool = Executors.newCachedThreadPool()
    private val main = Handler(Looper.getMainLooper())
    private var svc = false
    private var ticks = 0

    val tasks = CopyOnWriteArrayList<Task>()
    @Volatile var onChange: (() -> Unit)? = null

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs = ctx.getSharedPreferences("mdm", Context.MODE_PRIVATE)
        nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Unduhan", NotificationManager.IMPORTANCE_LOW))
        load()
        Executors.newSingleThreadScheduledExecutor().scheduleWithFixedDelay({ tick() }, 1, 1, TimeUnit.SECONDS)
    }

    // ---------- dipanggil dari UI ----------

    fun add(url: String, conns: Int) {
        val t = Task(System.currentTimeMillis(), url, guess(url), conns)
        tasks.add(0, t)
        start(t)
    }

    fun start(t: Task) {
        synchronized(t) {
            if (t.busy) {
                if (t.stop) t.again = true
                return
            }
            t.busy = true
            t.stop = false
            t.fail = false
            t.err = ""
        }
        t.status = RUNNING
        pool.execute {
            try {
                work(t)
            } finally {
                synchronized(t) { t.busy = false }
                if (t.again) {
                    t.again = false
                    start(t)
                }
            }
        }
        ping()
        refreshService()
    }

    fun pause(t: Task) {
        if (t.status != RUNNING) return
        t.stop = true
        t.status = PAUSED
        t.speed = 0
        pool.execute { drop(t) }
        ping(); save(); refreshService()
    }

    fun remove(t: Task, withFile: Boolean) {
        t.stop = true
        t.removed = true
        tasks.remove(t)
        pool.execute {
            drop(t)
            File(dir(), "${t.id}.part").delete()
            if (withFile && t.uri.isNotEmpty()) {
                try { ctx.contentResolver.delete(Uri.parse(t.uri), null, null) } catch (e: Exception) { }
            }
        }
        ping(); save(); refreshService()
    }

    // ---------- mesin ----------

    private fun work(t: Task) {
        try {
            if (t.segs.isEmpty()) probe(t)
            val f = File(dir(), "${t.id}.part")
            if (!t.ranged || !f.exists()) t.segs.forEach { it.done = 0L }
            RandomAccessFile(f, "rw").use { it.setLength(if (t.ranged) t.total else 0L) }
            val jobs = t.segs.filter { !it.fin }.map { s -> Callable<Unit> { segment(t, s, f) } }
            var e: Throwable? = null
            for (x in pool.invokeAll(jobs)) {
                try { x.get() } catch (ex: ExecutionException) { e = ex.cause ?: ex }
            }
            if (e != null) throw e
            if (t.stop) return
            if (t.total < 0) t.total = t.done
            finish(t, f)
        } catch (ex: Exception) {
            if (!t.stop) {
                t.status = FAILED
                t.err = ex.message ?: ex.javaClass.simpleName
            }
        } finally {
            ping(); save(); refreshService()
        }
    }

    /** Cek ukuran file & dukungan Range, lalu bagi file menjadi potongan sebanyak jumlah koneksi. */
    private fun probe(t: Task) {
        val c = request(t.url, "bytes=0-0")
        try {
            val code = c.responseCode
            var len = -1L
            if (code == 206) {
                len = c.getHeaderField("Content-Range")?.substringAfter('/', "")?.trim()?.toLongOrNull() ?: -1L
                t.ranged = len > 0
            } else if (code in 200..299) {
                len = c.contentLengthLong
            } else {
                throw IOException("HTTP $code")
            }
            t.total = len
            t.name = nameOf(c, t.url)
        } finally {
            c.disconnect()
        }
        val n = if (t.ranged && t.total >= 1_000_000) t.conns.coerceIn(1, 16) else 1
        val p = t.total / n
        t.segs = if (n == 1) {
            listOf(Seg(0L, if (t.total > 0) t.total - 1 else -1L))
        } else {
            List(n) { i -> Seg(i * p, if (i == n - 1) t.total - 1 else (i + 1) * p - 1) }
        }
    }

    private fun segment(t: Task, s: Seg, f: File) {
        var tries = 0
        while (!t.stop && !t.fail && !s.fin) {
            val before = s.done
            var c: HttpURLConnection? = null
            try {
                val range = if (t.ranged) "bytes=${s.start + s.done}-${if (s.end >= 0) s.end else ""}" else null
                val conn = request(t.url, range)
                c = conn
                t.links.add(conn)
                if (t.stop) return
                val code = conn.responseCode
                val ok = if (t.ranged) code == 206 else code in 200..299
                if (!ok) throw IOException("HTTP $code")
                RandomAccessFile(f, "rw").use { r ->
                    r.seek(s.start + s.done)
                    conn.inputStream.use { ins ->
                        val buf = ByteArray(65536)
                        while (!t.stop && !t.fail) {
                            val room = if (s.end >= 0) s.end - s.start - s.done + 1 else Long.MAX_VALUE
                            if (room <= 0) break
                            val n = ins.read(buf, 0, minOf(buf.size.toLong(), room).toInt())
                            if (n < 0) break
                            r.write(buf, 0, n)
                            s.done += n
                            t.tick.addAndGet(n.toLong())
                        }
                    }
                }
                if (s.fin || (s.end < 0 && !t.stop && !t.fail)) return
                if (!t.stop && !t.fail) throw IOException("Koneksi terputus")
            } catch (e: IOException) {
                if (t.stop || t.fail) return
                if (s.done > before) tries = 0
                if (++tries > 4) {
                    t.fail = true
                    throw e
                }
                Thread.sleep(1000L * tries)
            } finally {
                c?.let {
                    t.links.remove(it)
                    it.disconnect()
                }
            }
        }
    }

    /** Buka koneksi dan ikuti redirect manual (termasuk http <-> https). */
    private fun request(url: String, range: String?): HttpURLConnection {
        var u = url
        repeat(8) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Encoding", "identity")
            if (range != null) c.setRequestProperty("Range", range)
            val code = c.responseCode
            if (code !in 300..399) return c
            val loc = c.getHeaderField("Location")
            c.disconnect()
            u = URL(URL(u), loc ?: throw IOException("Redirect tanpa tujuan")).toString()
        }
        throw IOException("Terlalu banyak redirect")
    }

    /** Pindahkan file jadi ke folder Download/MisterDM lewat MediaStore. */
    private fun finish(t: Task, f: File) {
        t.status = SAVING
        t.speed = 0
        ping(); refreshService()
        val ext = t.name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val r = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, t.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MisterDM")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Gagal membuat file di folder Download")
        try {
            r.openOutputStream(u)!!.use { out -> FileInputStream(f).use { it.copyTo(out, 262144) } }
            v.clear()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(u, v, null, null)
        } catch (e: Exception) {
            r.delete(u, null, null)
            throw e
        }
        f.delete()
        if (t.removed) {
            r.delete(u, null, null)
            return
        }
        t.uri = u.toString()
        t.status = DONE
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            (t.id % 100000).toInt() + 10,
            Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(t.name).setContentText("Unduhan selesai").setContentIntent(pi).setAutoCancel(true).build()
        )
    }

    private fun drop(t: Task) {
        for (c in t.links) {
            try { c.disconnect() } catch (e: Exception) { }
        }
    }

    private fun dir(): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "dl").also { it.mkdirs() }

    // ---------- nama file ----------

    private fun dec(s: String) = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    private fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "download" }

    private fun guess(u: String) = clean(dec(u.substringBefore('#').substringBefore('?').substringAfterLast('/')))

    private fun nameOf(c: HttpURLConnection, url: String): String {
        val cd = c.getHeaderField("Content-Disposition") ?: return guess(url)
        val m = Regex("filename\\*\\s*=\\s*[^']*''([^;]+)", RegexOption.IGNORE_CASE).find(cd)
        if (m != null) return clean(dec(m.groupValues[1].trim()))
        val m2 = Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
        return if (m2 != null) clean(m2.groupValues[1].trim()) else guess(url)
    }

    // ---------- simpan, notifikasi, timer ----------

    fun save() {
        val a = JSONArray()
        for (t in tasks) {
            val s = JSONArray()
            for (g in t.segs) s.put(JSONArray().put(g.start).put(g.end).put(g.done))
            a.put(
                JSONObject().put("id", t.id).put("url", t.url).put("name", t.name).put("conns", t.conns)
                    .put("total", t.total).put("ranged", t.ranged).put("status", t.status)
                    .put("err", t.err).put("uri", t.uri).put("segs", s)
            )
        }
        prefs.edit().putString("tasks", a.toString()).apply()
    }

    private fun load() {
        try {
            val raw = prefs.getString("tasks", null) ?: return
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t = Task(o.getLong("id"), o.getString("url"), o.getString("name"), o.getInt("conns"))
                t.total = o.getLong("total")
                t.ranged = o.getBoolean("ranged")
                t.err = o.optString("err")
                t.uri = o.optString("uri")
                val st = o.getInt("status")
                t.status = if (st == DONE || st == FAILED) st else PAUSED
                val sa = o.getJSONArray("segs")
                t.segs = List(sa.length()) { k ->
                    val g = sa.getJSONArray(k)
                    Seg(g.getLong(0), g.getLong(1), g.getLong(2))
                }
                tasks.add(t)
            }
        } catch (e: Exception) { }
    }

    private fun active() = tasks.filter { it.status == RUNNING || it.status == SAVING }

    fun notif(): Notification {
        val a = active()
        val tot = a.sumOf { maxOf(it.total, 0L) }
        val dn = a.sumOf { it.done }
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Mister DM: ${a.size} unduhan")
            .setContentText(Formatter.formatFileSize(ctx, a.sumOf { it.speed }) + "/s")
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true)
        if (tot > 0) b.setProgress(1000, (dn * 1000 / tot).toInt(), false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun refreshService() {
        if (active().isEmpty()) {
            main.postDelayed({
                if (svc && active().isEmpty()) {
                    svc = false
                    ctx.stopService(Intent(ctx, DlService::class.java))
                    nm.cancel(1)
                }
            }, 1500)
            return
        }
        main.post {
            if (!svc) {
                svc = true
                try { ctx.startForegroundService(Intent(ctx, DlService::class.java)) } catch (e: Exception) { svc = false }
            }
        }
        nm.notify(1, notif())
    }

    private fun tick() {
        try {
            val a = active()
            if (a.isEmpty()) return
            for (t in a) t.speed = t.tick.getAndSet(0)
            if (++ticks % 3 == 0) save()
            ping()
            nm.notify(1, notif())
        } catch (e: Exception) { }
    }

    private fun ping() {
        onChange?.invoke()
    }
}

class DlService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Engine.init(this)
        startForeground(1, Engine.notif())
        return START_NOT_STICKY
    }
}
