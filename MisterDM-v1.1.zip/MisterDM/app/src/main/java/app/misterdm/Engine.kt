package app.misterdm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Icon
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import okhttp3.Call
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URL
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.Callable
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

const val RUNNING = 1
const val PAUSED = 2
const val DONE = 3
const val FAILED = 4
const val SAVING = 5
const val QUEUED = 6
const val WAITING = 7

const val K_FILE = 0
const val K_HLS = 1
const val K_PAGE = 2

const val ACT_PAUSE = "app.misterdm.PAUSE"
const val ACT_RESUME = "app.misterdm.RESUME"

private const val MIN_SPLIT = 4L * 1024 * 1024

class HttpErr(val code: Int) : IOException("HTTP $code")

/** Satu potongan file: byte start..end. [done] = byte yang sudah terunduh. end < 0 = ukuran tidak diketahui. */
class Seg(val start: Long, end: Long, d: Long = 0L) {
    @Volatile var end = end
    @Volatile var done = d
    @Volatile var taken = false
    val fin: Boolean get() = end >= 0 && start + done > end
}

class Task(val id: Long, val url: String, @Volatile var name: String, val conns: Int) {
    var kind = K_FILE
    @Volatile var total = -1L
    @Volatile var status = PAUSED
    @Volatile var speed = 0L
    @Volatile var stop = false
    @Volatile var fail = false
    @Volatile var busy = false
    @Volatile var again = false
    @Volatile var removed = false
    @Volatile var ranged = false
    @Volatile var direct = false
    @Volatile var err = ""
    @Volatile var uri = ""
    @Volatile var path = ""
    @Volatile var segs: List<Seg> = emptyList()
    @Volatile var hlsNext = 0
    @Volatile var hlsBytes = 0L
    @Volatile var hlsDone = 0L
    val tick = AtomicLong()
    val calls = CopyOnWriteArrayList<Call>()
    val done: Long get() = if (kind == K_HLS) hlsDone else segs.sumOf { it.done }
}

/**
 * Mesin unduh v1.1
 * - koneksi sungguhan paralel (HTTP/1.1), potongan dibagi ulang otomatis saat ada koneksi yang menganggur
 * - antrean, lanjut otomatis saat jaringan kembali, opsi Wi-Fi saja
 * - tulis langsung ke Download/MisterDM (izin "akses semua file"), cadangan: salin lewat MediaStore
 * - HLS (.m3u8) dan deteksi video di halaman web
 */
object Engine {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) MisterDM/1.1"
    private const val CH = "dl"
    private lateinit var ctx: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var nm: NotificationManager
    private val main = Handler(Looper.getMainLooper())
    private var svc = false
    private var ticks = 0
    @Volatile private var online = true
    @Volatile private var metered = false
    @Volatile private var showIdle = false

    internal val pool = Executors.newCachedThreadPool()
    internal val client: OkHttpClient = OkHttpClient.Builder()
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .connectionPool(ConnectionPool(32, 2, TimeUnit.MINUTES))
        .build()

    val tasks = CopyOnWriteArrayList<Task>()
    @Volatile var onChange: (() -> Unit)? = null

    var connsDefault: Int
        get() = prefs.getInt("conns", 8)
        set(v) { prefs.edit().putInt("conns", v).apply() }
    var maxParallel: Int
        get() = prefs.getInt("par", 2)
        set(v) {
            prefs.edit().putInt("par", v).apply()
            schedule()
        }
    var wifiOnly: Boolean
        get() = prefs.getBoolean("wifi", false)
        set(v) {
            prefs.edit().putBoolean("wifi", v).apply()
            netChanged()
        }
    var askedStorage: Boolean
        get() = prefs.getBoolean("asked", false)
        set(v) { prefs.edit().putBoolean("asked", v).apply() }

    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext
        prefs = ctx.getSharedPreferences("mdm", Context.MODE_PRIVATE)
        nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Unduhan", NotificationManager.IMPORTANCE_LOW))
        load()
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        upd(cur(cm))
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(n: Network, caps: NetworkCapabilities) {
                    upd(caps)
                }

                override fun onLost(n: Network) {
                    upd(cur(cm))
                }
            })
        } catch (e: Exception) { }
        schedule()
        Executors.newSingleThreadScheduledExecutor().scheduleWithFixedDelay({ tick() }, 1, 1, TimeUnit.SECONDS)
    }

    // ---------- jaringan ----------

    private fun cur(cm: ConnectivityManager): NetworkCapabilities? =
        cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }

    private fun upd(c: NetworkCapabilities?) {
        val o = c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val m = c == null || !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
        val changed = o != online || m != metered
        online = o
        metered = m
        if (changed) netChanged()
    }

    private fun allowed() = online && !(wifiOnly && metered)

    private fun netChanged() {
        if (!::prefs.isInitialized) return
        if (allowed()) {
            schedule()
            return
        }
        for (t in tasks) {
            if (t.status == RUNNING) {
                t.stop = true
                t.again = false
                t.status = WAITING
                t.speed = 0
                pool.execute { drop(t) }
            } else if (t.status == QUEUED) {
                t.status = WAITING
            }
        }
        ping(); save(); refreshService()
    }

    // ---------- dipanggil dari UI ----------

    fun add(url: String, conns: Int, kind: Int) {
        val t = Task(System.currentTimeMillis(), url, guess(url), conns)
        t.kind = kind
        t.status = QUEUED
        tasks.add(0, t)
        schedule()
    }

    fun start(t: Task) {
        if (t.status == PAUSED || t.status == FAILED) {
            t.status = QUEUED
            schedule()
        }
    }

    private fun pauseOne(t: Task) {
        when (t.status) {
            RUNNING -> {
                t.stop = true
                t.again = false
                t.status = PAUSED
                t.speed = 0
                pool.execute { drop(t) }
            }
            QUEUED, WAITING -> t.status = PAUSED
        }
    }

    private fun after() {
        ping(); save(); schedule()
    }

    fun pause(t: Task) {
        pauseOne(t)
        after()
    }

    fun pauseAll() {
        for (t in tasks) pauseOne(t)
        showIdle = true
        after()
    }

    fun resumeAll() {
        for (t in tasks) if (t.status == PAUSED) t.status = QUEUED
        schedule()
    }

    fun remove(t: Task, withFile: Boolean) {
        val st = t.status
        t.stop = true
        t.again = false
        t.removed = true
        tasks.remove(t)
        pool.execute {
            drop(t)
            try {
                if (st == DONE) {
                    if (withFile) {
                        if (t.direct) {
                            File(t.path).delete()
                        } else if (t.uri.isNotEmpty()) {
                            ctx.contentResolver.delete(Uri.parse(t.uri), null, null)
                        }
                    }
                } else {
                    if (t.path.isNotEmpty()) File(t.path).delete()
                    File(appDir(), "hls_${t.id}").deleteRecursively()
                }
            } catch (e: Exception) { }
        }
        after()
    }

    /** Periksa link: file biasa, playlist HLS, atau halaman web (cari link video/file di dalamnya). */
    fun resolve(url: String, cb: (Int, List<String>) -> Unit) {
        pool.execute {
            var kind = K_FILE
            var found: List<String> = emptyList()
            try {
                val p = url.substringBefore('?').substringBefore('#').lowercase()
                if (p.endsWith(".m3u8")) {
                    kind = K_HLS
                } else {
                    client.newCall(req(url)).execute().use { r ->
                        val ct = (r.header("Content-Type") ?: "").lowercase()
                        if (ct.contains("mpegurl")) {
                            kind = K_HLS
                        } else if (ct.startsWith("text/html") || ct.contains("xhtml")) {
                            kind = K_PAGE
                            found = sniff(r.peekBody(2000000).string(), url)
                        }
                    }
                }
            } catch (e: Exception) { }
            val k = kind
            val f = found
            main.post { cb(k, f) }
        }
    }

    private fun sniff(html: String, base: String): List<String> {
        val h = html.replace("\\/", "/").replace("&amp;", "&")
        val out = LinkedHashSet<String>()
        val ext = "(?:m3u8|mp4|webm|mkv|mp3|m4a|zip|apk)"
        val abs = Regex("https?://[^\\s\"'<>\\\\)]+?\\." + ext + "(?:\\?[^\\s\"'<>\\\\)]*)?", RegexOption.IGNORE_CASE)
        for (m in abs.findAll(h)) out.add(m.value)
        val rel = Regex("(?:src|href|content)\\s*=\\s*[\"']([^\"'#]+?\\." + ext + "(?:\\?[^\"']*)?)[\"']", RegexOption.IGNORE_CASE)
        for (m in rel.findAll(h)) {
            try { out.add(URL(URL(base), m.groupValues[1]).toString()) } catch (e: Exception) { }
        }
        return out.take(12)
    }

    // ---------- antrean ----------

    fun schedule() {
        synchronized(this) {
            val ok = allowed()
            var running = tasks.count { it.status == RUNNING }
            for (t in tasks.reversed()) {
                if (t.status != QUEUED && t.status != WAITING) continue
                if (!ok) {
                    t.status = WAITING
                } else if (running >= maxParallel) {
                    t.status = QUEUED
                } else {
                    running++
                    launch(t)
                }
            }
        }
        ping(); refreshService()
    }

    private fun launch(t: Task) {
        synchronized(t) {
            t.status = RUNNING
            if (t.busy) {
                t.again = true
                return
            }
            t.busy = true
            t.stop = false
            t.fail = false
            t.err = ""
        }
        pool.execute {
            try {
                work(t)
            } finally {
                synchronized(t) { t.busy = false }
                if (t.again) {
                    t.again = false
                    launch(t)
                }
            }
        }
    }

    // ---------- mesin unduh ----------

    private fun work(t: Task) {
        try {
            if (t.kind == K_HLS) Hls.work(t) else file(t)
        } catch (ex: Exception) {
            if (!t.stop) {
                if (!allowed()) {
                    t.status = WAITING
                } else {
                    t.status = FAILED
                    t.err = ex.message ?: ex.javaClass.simpleName
                }
            }
        } finally {
            t.speed = 0
            ping(); save(); schedule()
        }
    }

    private fun file(t: Task) {
        if (t.segs.isEmpty()) probe(t)
        if (t.path.isEmpty()) prepare(t, t.name)
        val f = File(t.path)
        f.parentFile?.mkdirs()
        if (!t.ranged || !f.exists()) t.segs.forEach { it.done = 0L }
        RandomAccessFile(f, "rw").use { raf ->
            raf.setLength(if (t.ranged) t.total else 0L)
            t.segs.forEach { it.taken = false }
            val ch = raf.channel
            val jobs = List(t.conns.coerceIn(1, 16)) { Callable<Unit> { worker(t, ch) } }
            var e: Throwable? = null
            for (x in pool.invokeAll(jobs)) {
                try { x.get() } catch (ex: ExecutionException) { e = ex.cause ?: ex }
            }
            if (e != null) throw e
        }
        if (t.stop) return
        if (t.total < 0) t.total = t.done
        finish(t, f)
    }

    private fun worker(t: Task, ch: FileChannel) {
        while (!t.stop && !t.fail) {
            val s = claim(t) ?: return
            try { fetch(t, s, ch) } finally { s.taken = false }
        }
    }

    /** Ambil potongan yang belum dikerjakan; kalau habis, belah potongan terbesar yang masih berjalan (seperti IDM). */
    private fun claim(t: Task): Seg? = synchronized(t) {
        val free = t.segs.firstOrNull { !it.taken && !it.fin }
        if (free != null) {
            free.taken = true
            free
        } else {
            split(t)
        }
    }

    private fun split(t: Task): Seg? {
        if (!t.ranged) return null
        var victim: Seg? = null
        var best = 0L
        for (s in t.segs) {
            if (s.taken && !s.fin) {
                val rem = s.end - (s.start + s.done) + 1
                if (rem > best) {
                    best = rem
                    victim = s
                }
            }
        }
        val v = victim ?: return null
        if (best < MIN_SPLIT) return null
        val mid = v.start + v.done + best / 2
        val n = Seg(mid, v.end)
        n.taken = true
        v.end = mid - 1
        t.segs = t.segs + n
        return n
    }

    private fun fetch(t: Task, s: Seg, ch: FileChannel) {
        var tries = 0
        val buf = ByteArray(256 * 1024)
        while (!t.stop && !t.fail && !s.fin) {
            val before = s.done
            var call: Call? = null
            try {
                val range = if (t.ranged) "bytes=${s.start + s.done}-${if (s.end >= 0) s.end else ""}" else null
                val c = client.newCall(req(t.url, range))
                call = c
                t.calls.add(c)
                if (t.stop) return
                c.execute().use { r ->
                    val ok = if (t.ranged) r.code == 206 else r.isSuccessful
                    if (!ok) throw HttpErr(r.code)
                    val ins = (r.body ?: throw IOException("Respons kosong")).byteStream()
                    while (!t.stop && !t.fail) {
                        val room = if (s.end >= 0) s.end - s.start - s.done + 1 else Long.MAX_VALUE
                        if (room <= 0) break
                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), room).toInt())
                        if (n < 0) break
                        val bb = ByteBuffer.wrap(buf, 0, n)
                        var pos = s.start + s.done
                        while (bb.hasRemaining()) pos += ch.write(bb, pos)
                        s.done += n
                        t.tick.addAndGet(n.toLong())
                    }
                }
                if (s.fin || (s.end < 0 && !t.stop && !t.fail)) return
                if (!t.stop && !t.fail) throw IOException("Koneksi terputus")
            } catch (e: IOException) {
                if (t.stop || t.fail) return
                if (e is HttpErr && e.code in 400..499 && e.code != 408 && e.code != 429) {
                    t.fail = true
                    throw e
                }
                if (s.done > before) tries = 0
                if (++tries > 4) {
                    t.fail = true
                    throw e
                }
                Thread.sleep(1000L * tries)
            } finally {
                call?.let { t.calls.remove(it) }
            }
        }
    }

    /** Cek ukuran file & dukungan Range, tentukan lokasi simpan, lalu bagi file menjadi potongan. */
    private fun probe(t: Task) {
        var name = t.name
        val c = client.newCall(req(t.url, "bytes=0-0"))
        t.calls.add(c)
        try {
            c.execute().use { r ->
                if (r.code == 206) {
                    val len = r.header("Content-Range")?.substringAfter('/', "")?.trim()?.toLongOrNull() ?: -1L
                    t.total = len
                    t.ranged = len > 0
                } else if (r.isSuccessful) {
                    t.total = r.body?.contentLength() ?: -1L
                    t.ranged = false
                } else {
                    throw HttpErr(r.code)
                }
                name = nameOf(r, t.url)
            }
        } finally {
            t.calls.remove(c)
        }
        prepare(t, name)
        val n = if (t.ranged && t.total >= 1000000) t.conns.coerceIn(1, 16) else 1
        val p = t.total / n
        t.segs = if (n == 1) {
            listOf(Seg(0L, if (t.total > 0) t.total - 1 else -1L))
        } else {
            List(n) { i -> Seg(i * p, if (i == n - 1) t.total - 1 else (i + 1) * p - 1) }
        }
    }

    // ---------- lokasi & nama file ----------

    internal fun appDir(): File = (ctx.getExternalFilesDir(null) ?: ctx.filesDir).also { it.mkdirs() }

    private fun publicDir(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MisterDM").also { it.mkdirs() }

    /** Tentukan file sementara (.part). Dengan izin "akses semua file" langsung di Download/MisterDM, kalau tidak di folder app. */
    internal fun prepare(t: Task, name: String) {
        if (t.path.isNotEmpty()) return
        val n = clean(name)
        t.direct = Environment.isExternalStorageManager()
        if (t.direct) {
            val d = publicDir()
            val u = uniq(d, n)
            t.name = u
            t.path = File(d, "$u.part").path
        } else {
            t.name = n
            t.path = File(appDir(), "${t.id}.part").path
        }
    }

    private fun uniq(d: File, n: String): String {
        val dot = n.lastIndexOf('.')
        val base = if (dot > 0) n.substring(0, dot) else n
        val ext = if (dot > 0) n.substring(dot) else ""
        var c = n
        var i = 1
        while (File(d, c).exists() || File(d, "$c.part").exists()) {
            c = "$base ($i)$ext"
            i++
        }
        return c
    }

    private fun dec(s: String) = try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    private fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "download" }

    private fun guess(u: String) = clean(dec(u.substringBefore('#').substringBefore('?').substringAfterLast('/')))

    private fun nameOf(r: Response, url: String): String {
        val cd = r.header("Content-Disposition") ?: return guess(url)
        val m = Regex("filename\\*\\s*=\\s*[^']*''([^;]+)", RegexOption.IGNORE_CASE).find(cd)
        if (m != null) return clean(dec(m.groupValues[1].trim()))
        val m2 = Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
        return if (m2 != null) clean(m2.groupValues[1].trim()) else guess(url)
    }

    // ---------- selesai ----------

    internal fun finish(t: Task, f: File) {
        t.status = SAVING
        t.speed = 0
        ping(); refreshService()
        if (t.direct) {
            val dest = File(f.path.removeSuffix(".part"))
            if (!f.renameTo(dest)) throw IOException("Gagal mengganti nama file")
            t.path = dest.path
            if (t.removed) {
                dest.delete()
                return
            }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), null, null)
        } else {
            val ext = t.name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            val r = ctx.contentResolver
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, t.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MisterDM")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val u = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IOException("Gagal membuat file di folder Download")
            try {
                r.openOutputStream(u)!!.use { out -> FileInputStream(f).use { it.copyTo(out, 262144) } }
                v.clear()
                v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                r.update(u, v, null, null)
            } catch (e: Exception) {
                r.delete(u, null, null)
                throw e
            }
            f.delete()
            if (t.removed) {
                r.delete(u, null, null)
                return
            }
            t.uri = u.toString()
        }
        t.status = DONE
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            (t.id % 100000).toInt() + 10,
            Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(t.name).setContentText("Unduhan selesai").setContentIntent(pi).setAutoCancel(true).build()
        )
    }

    internal fun drop(t: Task) {
        for (c in t.calls) {
            try { c.cancel() } catch (e: Exception) { }
        }
    }

    // ---------- HTTP ----------

    internal fun req(url: String, range: String? = null): Request {
        val b = Request.Builder().url(url).header("User-Agent", UA).header("Accept-Encoding", "identity")
        if (range != null) b.header("Range", range)
        return b.build()
    }

    internal fun text(t: Task, url: String): String {
        val c = client.newCall(req(url))
        t.calls.add(c)
        try {
            return c.execute().use { r ->
                if (!r.isSuccessful) throw HttpErr(r.code)
                (r.body ?: throw IOException("Respons kosong")).string()
            }
        } finally {
            t.calls.remove(c)
        }
    }

    internal fun bytes(t: Task, url: String): ByteArray {
        val c = client.newCall(req(url))
        t.calls.add(c)
        try {
            return c.execute().use { r ->
                if (!r.isSuccessful) throw HttpErr(r.code)
                (r.body ?: throw IOException("Respons kosong")).bytes()
            }
        } finally {
            t.calls.remove(c)
        }
    }

    // ---------- simpan & muat status ----------

    fun save() {
        val a = JSONArray()
        for (t in tasks) {
            val s = JSONArray()
            for (g in t.segs) s.put(JSONArray().put(g.start).put(g.end).put(g.done))
            val o = JSONObject()
            o.put("id", t.id).put("url", t.url).put("name", t.name).put("conns", t.conns).put("kind", t.kind)
            o.put("total", t.total).put("ranged", t.ranged).put("direct", t.direct).put("status", t.status)
            o.put("err", t.err).put("uri", t.uri).put("path", t.path)
            o.put("hn", t.hlsNext).put("hb", t.hlsBytes).put("hd", t.hlsDone).put("segs", s)
            a.put(o)
        }
        prefs.edit().putString("tasks", a.toString()).apply()
    }

    private fun load() {
        try {
            val raw = prefs.getString("tasks", null) ?: return
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t = Task(o.getLong("id"), o.getString("url"), o.getString("name"), o.getInt("conns"))
                t.kind = o.optInt("kind", K_FILE)
                t.total = o.getLong("total")
                t.ranged = o.getBoolean("ranged")
                t.direct = o.optBoolean("direct", false)
                t.err = o.optString("err")
                t.uri = o.optString("uri")
                t.path = o.optString("path")
                t.hlsNext = o.optInt("hn", 0)
                t.hlsBytes = o.optLong("hb", 0L)
                t.hlsDone = o.optLong("hd", 0L)
                val st = o.getInt("status")
                // yang sedang berjalan saat app mati dilanjutkan otomatis
                t.status = if (st == DONE || st == FAILED || st == PAUSED) st else WAITING
                val sa = o.getJSONArray("segs")
                t.segs = List(sa.length()) { k ->
                    val g = sa.getJSONArray(k)
                    Seg(g.getLong(0), g.getLong(1), g.getLong(2))
                }
                tasks.add(t)
            }
        } catch (e: Exception) { }
    }

    // ---------- notifikasi & layanan ----------

    private fun live() = tasks.any {
        it.status == RUNNING || it.status == SAVING || it.status == QUEUED || it.status == WAITING
    }

    private fun act(a: String, label: String, icon: Int, code: Int): Notification.Action {
        val pi = PendingIntent.getForegroundService(
            ctx, code, Intent(ctx, DlService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(Icon.createWithResource(ctx, icon), label, pi).build()
    }

    fun notif(): Notification {
        val active = tasks.filter { it.status == RUNNING || it.status == SAVING }
        val waiting = tasks.count { it.status == WAITING || it.status == QUEUED }
        val tot = active.sumOf { maxOf(it.total, 0L) }
        val dn = active.sumOf { it.done }
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true)
            .addAction(act(ACT_PAUSE, "Jeda semua", android.R.drawable.ic_media_pause, 1))
        if (active.isEmpty()) {
            b.setContentTitle("Mister DM")
            b.setContentText(if (waiting > 0) "Menunggu jaringan atau antrean ($waiting)" else "Bersiap")
        } else {
            b.setContentTitle("Mister DM: ${active.size} unduhan" + (if (waiting > 0) ", $waiting menunggu" else ""))
            b.setContentText(Formatter.formatFileSize(ctx, active.sumOf { it.speed }) + "/s")
            if (tot > 0) b.setProgress(1000, (dn * 1000 / tot).toInt().coerceIn(0, 1000), false) else b.setProgress(0, 0, true)
        }
        return b.build()
    }

    private fun idle(n: Int): Notification {
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Mister DM").setContentText("$n unduhan dijeda").setContentIntent(pi)
            .addAction(act(ACT_RESUME, "Lanjutkan semua", android.R.drawable.ic_media_play, 2)).build()
    }

    private fun refreshService() {
        if (!live()) {
            main.postDelayed({
                if (!live()) {
                    if (svc) {
                        svc = false
                        ctx.stopService(Intent(ctx, DlService::class.java))
                    }
                    nm.cancel(1)
                    val paused = tasks.count { it.status == PAUSED }
                    if (showIdle && paused > 0) nm.notify(2, idle(paused)) else nm.cancel(2)
                }
            }, 1500)
            return
        }
        showIdle = false
        nm.cancel(2)
        main.post {
            if (!svc) {
                svc = true
                try {
                    ctx.startForegroundService(Intent(ctx, DlService::class.java))
                } catch (e: Exception) {
                    svc = false
                }
            }
        }
        nm.notify(1, notif())
    }

    private fun tick() {
        try {
            val a = tasks.filter { it.status == RUNNING }
            if (a.isEmpty()) return
            for (t in a) t.speed = t.tick.getAndSet(0)
            if (++ticks % 3 == 0) save()
            ping()
            nm.notify(1, notif())
        } catch (e: Exception) { }
    }

    private fun ping() {
        onChange?.invoke()
    }
}

class DlService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Engine.init(this)
        startForeground(1, Engine.notif())
        when (intent?.action) {
            ACT_PAUSE -> Engine.pauseAll()
            ACT_RESUME -> Engine.resumeAll()
        }
        return START_NOT_STICKY
    }
}
