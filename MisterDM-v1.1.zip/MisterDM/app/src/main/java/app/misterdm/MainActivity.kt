package app.misterdm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

private val INK = Color.parseColor("#1A2430")
private val TRACK = Color.parseColor("#2E3E50")
private val TEAL = Color.parseColor("#2DD4BF")
private val AMBER = Color.parseColor("#F5B544")
private val CORAL = Color.parseColor("#F0705A")
private val SLATE = Color.parseColor("#5B6B7D")
private val TEXT = Color.parseColor("#E8EEF4")
private val MUTED = Color.parseColor("#8FA1B3")

/** Bar progres bersegmen: satu blok per koneksi, seperti tampilan per-koneksi di IDM. Warna bar = status unduhan. */
class SegBar(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private var segs: List<Seg> = emptyList()
    private var total = 0L
    private var full = false
    private var color = TEAL

    fun set(t: Task) {
        total = t.total
        segs = if (t.kind == K_HLS) listOf(Seg(0L, maxOf(total, 1L) - 1, t.done)) else t.segs
        full = t.status == DONE || t.status == SAVING
        color = when (t.status) {
            PAUSED -> AMBER
            FAILED -> CORAL
            QUEUED, WAITING -> SLATE
            else -> TEAL
        }
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, h / 2, h / 2, Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        cv.drawColor(TRACK)
        p.color = color
        if (full) {
            cv.drawRect(0f, 0f, w, h, p)
        } else if (total > 0) {
            for (s in segs) cv.drawRect(w * s.start / total, 0f, w * (s.start + s.done) / total, h, p)
        } else if (segs.isNotEmpty() && segs[0].done > 0) {
            p.alpha = 110
            cv.drawRect(0f, 0f, w, h, p)
            p.alpha = 255
        }
        p.color = INK
        if (total > 0) {
            for (i in 1 until segs.size) {
                val x = w * segs[i].start / total
                cv.drawRect(x - 1.5f, 0f, x + 1.5f, h, p)
            }
        }
        cv.restore()
    }
}

class Row(c: Context) : LinearLayout(c) {
    private val name = TextView(c)
    private val bar = SegBar(c)
    private val left = TextView(c)
    private val right = TextView(c)

    init {
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
        name.setTextColor(TEXT)
        name.textSize = 15f
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.MIDDLE
        name.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        for (v in listOf(left, right)) {
            v.setTextColor(MUTED)
            v.textSize = 12f
        }
        left.maxLines = 2
        right.gravity = Gravity.END
        val meta = LinearLayout(c)
        meta.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        meta.addView(right, LinearLayout.LayoutParams(-2, -2))
        addView(name)
        addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        addView(meta)
    }

    private fun clock(s: Long) =
        if (s >= 3600) "${s / 3600} jam ${s % 3600 / 60} mnt" else String.format("%d:%02d", s / 60, s % 60)

    fun bind(t: Task) {
        val tot = t.total
        val dn = t.done
        fun fs(x: Long) = Formatter.formatFileSize(context, x)
        name.text = t.name
        bar.set(t)
        when (t.status) {
            RUNNING -> {
                left.text = if (tot > 0) "${fs(dn)} dari ${fs(tot)}" else fs(dn)
                val eta = if (t.speed > 0 && tot > 0) ", sisa " + clock((tot - dn) / t.speed) else ""
                right.text = if (t.speed > 0) fs(t.speed) + "/s" + eta else "Menghubungkan"
            }
            SAVING -> {
                left.text = "Menyimpan ke folder Download"
                right.text = ""
            }
            DONE -> {
                left.text = "Selesai, ${fs(tot)}"
                right.text = "Ketuk untuk buka"
            }
            FAILED -> {
                left.text = "Gagal: ${t.err}"
                right.text = "Ketuk untuk ulangi"
            }
            QUEUED -> {
                left.text = "Mengantre"
                right.text = "Ketuk untuk jeda"
            }
            WAITING -> {
                left.text = "Menunggu jaringan"
                right.text = "Lanjut otomatis"
            }
            else -> {
                val of = if (tot > 0) " dari ${fs(tot)}" else ""
                left.text = "Dijeda di ${fs(dn)}$of"
                right.text = "Ketuk untuk lanjut"
            }
        }
    }
}

class MainActivity : Activity() {
    private lateinit var adp: BaseAdapter
    private lateinit var speedTv: TextView
    private var notifAsked = false

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Engine.init(this)
        window.statusBarColor = INK
        window.navigationBarColor = INK

        speedTv = TextView(this).apply {
            setTextColor(TEAL)
            textSize = 13f
        }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(10))
            addView(TextView(context).apply {
                text = "Mister DM"
                textSize = 24f
                setTextColor(TEXT)
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(speedTv)
            addView(TextView(context).apply {
                text = "Pengaturan"
                textSize = 13f
                setTextColor(MUTED)
                setPadding(dp(16), dp(6), 0, dp(6))
                setOnClickListener { showSettings() }
            })
        }

        adp = object : BaseAdapter() {
            override fun getCount() = Engine.tasks.size
            override fun getItem(p: Int): Any = Engine.tasks[p]
            override fun getItemId(p: Int) = Engine.tasks[p].id
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = cv as? Row ?: Row(this@MainActivity)
                row.bind(Engine.tasks[p])
                return row
            }
        }
        val list = ListView(this).apply {
            adapter = adp
            divider = ColorDrawable(TRACK)
            dividerHeight = 1
            setOnItemClickListener { _, _, p, _ -> tap(Engine.tasks.getOrNull(p)) }
            setOnItemLongClickListener { _, _, p, _ ->
                menu(Engine.tasks.getOrNull(p))
                true
            }
        }
        val empty = TextView(this).apply {
            text = "Belum ada unduhan.\nKetuk + untuk menempel link, atau bagikan link dari browser ke Mister DM."
            setTextColor(MUTED)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
        }
        list.emptyView = empty
        val fab = TextView(this).apply {
            text = "+"
            textSize = 30f
            setTextColor(INK)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            elevation = dp(6).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(TEAL)
            }
            setOnClickListener { showAdd(null) }
        }
        val frame = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(20), dp(24))
            })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(INK)
            addView(head)
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        })

        if (!Environment.isExternalStorageManager() && !Engine.askedStorage) storageDialog() else askNotif()
        if (b == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        Engine.onChange = { runOnUiThread { refresh() } }
        refresh()
        if (Engine.askedStorage || Environment.isExternalStorageManager()) askNotif()
    }

    override fun onPause() {
        super.onPause()
        Engine.onChange = null
    }

    private fun refresh() {
        adp.notifyDataSetChanged()
        val sp = Engine.tasks.filter { it.status == RUNNING }.sumOf { it.speed }
        speedTv.text = if (sp > 0) Formatter.formatFileSize(this, sp) + "/s" else ""
    }

    // ---------- izin ----------

    private fun askNotif() {
        if (notifAsked) return
        notifAsked = true
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun askStorage() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                toast("Buka Pengaturan > Aplikasi > Mister DM > Izin untuk mengaktifkan akses semua file")
            }
        }
    }

    private fun storageDialog() {
        AlertDialog.Builder(this).setTitle("Izin akses semua file")
            .setMessage(
                "Aktifkan \"Akses semua file\" agar unduhan langsung tersimpan di folder Download tanpa disalin lagi " +
                    "(hemat ruang dan waktu). Tanpa izin ini, file disalin dulu di akhir sehingga butuh ruang dua kali lipat."
            )
            .setPositiveButton("Buka pengaturan") { _, _ -> askStorage() }
            .setNegativeButton("Nanti") { _, _ -> askNotif() }
            .setOnDismissListener { Engine.askedStorage = true }
            .show()
    }

    // ---------- pengaturan ----------

    private fun showSettings() {
        fun label(s: String) = TextView(this).apply {
            text = s
            setTextColor(MUTED)
            textSize = 12f
            setPadding(0, dp(14), 0, 0)
        }

        fun spin(items: Array<String>, sel: Int) = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
        }

        val connItems = arrayOf("1", "2", "4", "8", "16")
        val parItems = arrayOf("1", "2", "3", "4", "5")
        val sc = spin(connItems, connItems.indexOf(Engine.connsDefault.toString()).coerceAtLeast(0))
        val sp = spin(parItems, (Engine.maxParallel - 1).coerceIn(0, 4))
        val wifi = Switch(this).apply {
            text = "Hanya lewat Wi-Fi / jaringan tanpa kuota"
            isChecked = Engine.wifiOnly
            setTextColor(TEXT)
            setPadding(0, dp(16), 0, dp(4))
        }
        val granted = Environment.isExternalStorageManager()
        val perm = TextView(this).apply {
            text = if (granted) "Akses semua file: aktif" else "Akses semua file: belum aktif. Ketuk untuk mengaktifkan (hemat ruang)."
            setTextColor(if (granted) TEAL else AMBER)
            textSize = 13f
            setPadding(0, dp(14), 0, dp(6))
            setOnClickListener { askStorage() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(label("Koneksi per file (bawaan)"))
            addView(sc)
            addView(label("Unduhan bersamaan"))
            addView(sp)
            addView(wifi)
            addView(perm)
        }
        AlertDialog.Builder(this).setTitle("Pengaturan").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                Engine.connsDefault = connItems[sc.selectedItemPosition].toInt()
                Engine.maxParallel = parItems[sp.selectedItemPosition].toInt()
                Engine.wifiOnly = wifi.isChecked
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- tambah unduhan ----------

    /** Link yang dibagikan dari browser (Bagikan > Mister DM) membuka dialog tambah. */
    private fun handle(i: Intent?) {
        val a = i ?: return
        if (a.action != Intent.ACTION_SEND) return
        val m = Regex("(?:https?://|magnet:)\\S+").find(a.getStringExtra(Intent.EXTRA_TEXT) ?: "") ?: return
        showAdd(m.value)
    }

    private fun clip(): String = try {
        val c = getSystemService(ClipboardManager::class.java).primaryClip
        val s = if (c != null && c.itemCount > 0) c.getItemAt(0).text?.toString()?.trim() else null
        if (s != null && Regex("(?i)(?:https?://|magnet:)\\S+").matches(s)) s else ""
    } catch (e: Exception) {
        ""
    }

    private fun showAdd(pre: String?) {
        val et = EditText(this).apply {
            hint = "Tempel link unduhan, halaman video, atau magnet"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(pre ?: clip())
        }
        val connItems = arrayOf("1", "2", "4", "8", "16")
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, connItems)
            setSelection(connItems.indexOf(Engine.connsDefault.toString()).coerceAtLeast(0))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(et)
            addView(TextView(context).apply {
                text = "Koneksi per file"
                setTextColor(MUTED)
                textSize = 12f
                setPadding(0, dp(14), 0, 0)
            })
            addView(sp)
        }
        AlertDialog.Builder(this).setTitle("Tambah unduhan").setView(box)
            .setPositiveButton("Unduh") { _, _ ->
                var u = et.text.toString().trim()
                if (u.startsWith("magnet:", true) || u.substringBefore('?').endsWith(".torrent", true)) {
                    torrent(u)
                } else {
                    if (!u.contains("://")) u = "https://$u"
                    val link = u
                    if (Regex("(?i)https?://[^\\s/]+\\S*").matches(link)) {
                        val n = connItems[sp.selectedItemPosition].toInt()
                        toast("Memeriksa link…")
                        Engine.resolve(link) { kind, urls -> found(link, n, kind, urls) }
                    } else {
                        toast("Link tidak valid. Mulai dengan http:// atau https://")
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun found(u: String, n: Int, kind: Int, urls: List<String>) {
        if (kind != K_PAGE) {
            Engine.add(u, n, kind)
            return
        }
        if (urls.isEmpty()) {
            toast("Tidak ada video atau file yang ditemukan di halaman ini")
            return
        }
        val names = urls.map { link -> link.substringBefore('?').substringAfterLast('/').ifEmpty { link } }
        AlertDialog.Builder(this).setTitle("Ditemukan di halaman")
            .setItems(names.toTypedArray()) { _, i ->
                val pu = urls[i]
                val hls = pu.substringBefore('?').lowercase().endsWith(".m3u8")
                Engine.add(pu, n, if (hls) K_HLS else K_FILE)
            }
            .show()
    }

    /** Mesin torrent bawaan belum ada: teruskan magnet / .torrent ke aplikasi torrent yang terpasang. */
    private fun torrent(u: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
            if (!u.startsWith("magnet:", true)) i.setDataAndType(Uri.parse(u), "application/x-bittorrent")
            startActivity(i)
        } catch (e: Exception) {
            toast("Belum ada aplikasi torrent terpasang. Pasang satu dulu, lalu coba lagi.")
        }
    }

    // ---------- daftar ----------

    private fun tap(t: Task?) {
        if (t == null) return
        when (t.status) {
            DONE -> open(t)
            RUNNING, QUEUED, WAITING -> Engine.pause(t)
            SAVING -> {}
            else -> Engine.start(t)
        }
    }

    private fun menu(t: Task?) {
        if (t == null) return
        AlertDialog.Builder(this).setTitle(t.name)
            .setItems(arrayOf("Salin link", "Hapus dari daftar", "Hapus beserta file")) { _, which ->
                when (which) {
                    0 -> {
                        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("url", t.url))
                        toast("Link disalin")
                    }
                    1 -> Engine.remove(t, false)
                    else -> Engine.remove(t, true)
                }
            }.show()
    }

    private fun open(t: Task) {
        try {
            val ext = t.name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val u = if (t.direct) FileProvider.getUriForFile(this, "app.misterdm.files", File(t.path)) else Uri.parse(t.uri)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            toast("Tidak ada aplikasi yang bisa membuka file ini, atau file sudah dihapus")
        }
    }
}
