package app.misterdm

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Unduh video HLS (.m3u8) bertipe VOD: pilih kualitas tertinggi, unduh segmen paralel,
 * gabungkan berurutan jadi satu file (.ts, atau .mp4 untuk fMP4). Mendukung enkripsi AES-128 biasa.
 * Tidak mendukung DRM, siaran langsung, dan playlist byte-range.
 */
object Hls {
    private class Part(val url: String, val keyUrl: String?, val iv: ByteArray?, val seq: Int)

    private fun abs(base: String, ref: String): String = URL(URL(base), ref).toString()

    private fun attr(line: String, name: String): String? =
        Regex("(?:^|[,:])" + name + "=(\"[^\"]*\"|[^,]*)").find(line)?.groupValues?.get(1)?.trim('"')

    private fun hex(s: String): ByteArray {
        val h = s.removePrefix("0x").removePrefix("0X").padStart(32, '0')
        return ByteArray(16) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun ivOf(seq: Int): ByteArray {
        val b = ByteArray(16)
        for (k in 0..3) b[15 - k] = (seq shr (8 * k)).toByte()
        return b
    }

    fun work(t: Task) {
        var base = t.url
        var text = Engine.text(t, base)
        if (text.contains("#EXT-X-STREAM-INF")) {
            val lines = text.lines()
            var best = -1L
            var pick: String? = null
            for (i in lines.indices) {
                val l = lines[i].trim()
                if (!l.startsWith("#EXT-X-STREAM-INF")) continue
                val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
                if (j < lines.size && bw > best) {
                    best = bw
                    pick = lines[j].trim()
                }
            }
            val u = pick ?: throw IOException("Playlist tidak berisi video")
            base = abs(base, u)
            text = Engine.text(t, base)
        }

        var seq = 0
        var enc = false
        var keyUrl: String? = null
        var iv: ByteArray? = null
        var map: String? = null
        var ended = false
        var pending = false
        val parts = ArrayList<Part>()
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                seq = l.substringAfter(':').trim().toIntOrNull() ?: 0
            } else if (l.startsWith("#EXT-X-KEY:")) {
                val m = attr(l, "METHOD")
                if (m == "NONE") {
                    enc = false
                    keyUrl = null
                    iv = null
                } else if (m == "AES-128") {
                    enc = true
                    keyUrl = attr(l, "URI")?.let { abs(base, it) }
                    iv = attr(l, "IV")?.let { hex(it) }
                } else {
                    throw IOException("Video terenkripsi (DRM) tidak didukung")
                }
            } else if (l.startsWith("#EXT-X-MAP:")) {
                map = attr(l, "URI")?.let { abs(base, it) }
            } else if (l.startsWith("#EXT-X-BYTERANGE")) {
                throw IOException("Playlist byte-range belum didukung")
            } else if (l.startsWith("#EXT-X-ENDLIST")) {
                ended = true
            } else if (l.startsWith("#EXTINF")) {
                pending = true
            } else if (!l.startsWith("#") && pending) {
                parts.add(Part(abs(base, l), if (enc) keyUrl else null, if (enc) iv else null, seq + parts.size))
                pending = false
            }
        }
        if (parts.isEmpty()) throw IOException("Tidak ada segmen video")
        if (!ended) throw IOException("Siaran langsung (live) belum didukung")

        val mapUrl = map
        Engine.prepare(t, t.name.substringBeforeLast('.', t.name) + (if (mapUrl != null) ".mp4" else ".ts"))
        val out = File(t.path)
        out.parentFile?.mkdirs()
        val tmp = File(Engine.appDir(), "hls_${t.id}")
        tmp.deleteRecursively()
        tmp.mkdirs()

        val n = parts.size
        val got = AtomicLong(t.hlsBytes)
        t.hlsDone = t.hlsBytes
        val doneCount = AtomicInteger(t.hlsNext)
        val next = AtomicInteger(t.hlsNext)
        val win = Semaphore(24)
        val lock = Any()
        val keys = HashMap<String, ByteArray>()
        val ready = arrayOfNulls<File>(n)
        var w = t.hlsNext
        var failure: Throwable? = null

        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(t.hlsBytes)
            raf.seek(t.hlsBytes)
            if (t.hlsNext == 0 && t.hlsBytes == 0L && mapUrl != null) {
                val f0 = File(tmp, "init")
                grab(t, mapUrl, f0, null, null, got)
                if (!t.stop && !t.fail) {
                    raf.write(f0.readBytes())
                    f0.delete()
                    t.hlsBytes = raf.filePointer
                }
            }
            val jobs = List(t.conns.coerceIn(1, 16)) {
                Callable<Unit> {
                    while (!t.stop && !t.fail) {
                        if (!win.tryAcquire(500, TimeUnit.MILLISECONDS)) continue
                        val i = next.getAndIncrement()
                        if (i >= n) {
                            win.release()
                            break
                        }
                        val p = parts[i]
                        val f = File(tmp, "$i")
                        val key = p.keyUrl?.let { u -> synchronized(keys) { keys.getOrPut(u) { Engine.bytes(t, u) } } }
                        grab(t, p.url, f, key, if (key != null) (p.iv ?: ivOf(p.seq)) else null, got)
                        if (t.stop || t.fail) {
                            f.delete()
                            break
                        }
                        val dc = doneCount.incrementAndGet()
                        synchronized(lock) {
                            ready[i] = f
                            while (w < n && ready[w] != null) {
                                val rf = ready[w]!!
                                rf.inputStream().use { ins ->
                                    val b = ByteArray(262144)
                                    while (true) {
                                        val r = ins.read(b)
                                        if (r < 0) break
                                        raf.write(b, 0, r)
                                    }
                                }
                                rf.delete()
                                ready[w] = null
                                w++
                                win.release()
                                t.hlsNext = w
                                t.hlsBytes = raf.filePointer
                            }
                        }
                        t.total = got.get() / dc * n
                    }
                }
            }
            for (x in Engine.pool.invokeAll(jobs)) {
                try { x.get() } catch (ex: ExecutionException) { failure = ex.cause ?: ex }
            }
        }
        val fe = failure
        if (fe != null) throw fe
        if (t.stop) return
        tmp.deleteRecursively()
        t.total = got.get()
        t.hlsDone = t.total
        Engine.finish(t, out)
    }

    /** Unduh satu URL ke file; dekripsi AES-128 kalau [key] ada. Coba ulang untuk gangguan jaringan. */
    private fun grab(t: Task, url: String, dest: File, key: ByteArray?, iv: ByteArray?, got: AtomicLong) {
        var tries = 0
        while (true) {
            val c = Engine.client.newCall(Engine.req(url))
            t.calls.add(c)
            try {
                if (t.stop) return
                c.execute().use { r ->
                    if (!r.isSuccessful) throw HttpErr(r.code)
                    var ins: InputStream = (r.body ?: throw IOException("Respons kosong")).byteStream()
                    if (key != null) {
                        val ci = Cipher.getInstance("AES/CBC/PKCS5Padding")
                        ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv ?: ByteArray(16)))
                        ins = CipherInputStream(ins, ci)
                    }
                    dest.outputStream().use { out ->
                        val b = ByteArray(65536)
                        while (!t.stop && !t.fail) {
                            val n = ins.read(b)
                            if (n < 0) break
                            out.write(b, 0, n)
                            t.hlsDone = got.addAndGet(n.toLong())
                            t.tick.addAndGet(n.toLong())
                            Limiter.take(n)
                        }
                    }
                }
                return
            } catch (e: IOException) {
                if (t.stop || t.fail) return
                if (e is HttpErr && e.code in 400..499 && e.code != 408 && e.code != 429) {
                    t.fail = true
                    throw e
                }
                if (++tries > 4) {
                    t.fail = true
                    throw e
                }
                Thread.sleep(1000L * tries)
            } finally {
                t.calls.remove(c)
            }
        }
    }
}
