package app.misterdm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

private val INK = Color.parseColor("#1A2430")
private val TRACK = Color.parseColor("#2E3E50")
private val TEAL = Color.parseColor("#2DD4BF")
private val AMBER = Color.parseColor("#F5B544")
private val CORAL = Color.parseColor("#F0705A")
private val SLATE = Color.parseColor("#5B6B7D")
private val SKY = Color.parseColor("#6CB6FF")
private val TEXT = Color.parseColor("#E8EEF4")
private val MUTED = Color.parseColor("#8FA1B3")

/** Bar progres: blok terisi digabung jadi satu garis mulus; penanda kecil = posisi tiap koneksi yang sedang aktif. */
class SegBar(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private var segs: List<Seg> = emptyList()
    private var total = 0L
    private var full = false
    private var live = false
    private var color = TEAL

    fun set(t: Task) {
        val ex = t.status == DONE && t.xs == 1
        total = if (ex) t.xtotal else t.total
        segs = if (ex) {
            listOf(Seg(0L, maxOf(t.xtotal, 1L) - 1, t.xdone))
        } else if (t.kind == K_HLS) {
            listOf(Seg(0L, maxOf(t.total, 1L) - 1, t.done))
        } else {
            t.segs
        }
        full = (t.status == DONE && !ex) || t.status == SAVING
        live = t.status == RUNNING && t.kind != K_HLS
        color = if (ex) SKY else when (t.status) {
            PAUSED -> AMBER
            FAILED -> CORAL
            QUEUED, WAITING -> SLATE
            else -> TEAL
        }
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, h / 2, h / 2, Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        cv.drawColor(TRACK)
        p.color = color
        if (full) {
            cv.drawRect(0f, 0f, w, h, p)
        } else if (total > 0) {
            var cs = -1L
            var ce = -1L
            for (s in segs.filter { it.done > 0 }.sortedBy { it.start }) {
                val e = s.start + s.done
                if (cs < 0) {
                    cs = s.start
                    ce = e
                } else if (s.start <= ce) {
                    if (e > ce) ce = e
                } else {
                    cv.drawRect(w * cs / total, 0f, w * ce / total, h, p)
                    cs = s.start
                    ce = e
                }
            }
            if (cs >= 0) cv.drawRect(w * cs / total, 0f, w * ce / total, h, p)
            if (live) {
                p.color = TEXT
                for (s in segs) {
                    if (s.taken && !s.fin) {
                        val x = w * (s.start + s.done) / total
                        cv.drawRect(x - 1.5f, 0f, x + 1.5f, h, p)
                    }
                }
            }
        } else if (segs.isNotEmpty() && segs[0].done > 0) {
            p.alpha = 110
            cv.drawRect(0f, 0f, w, h, p)
            p.alpha = 255
        }
        cv.restore()
    }
}

class Row(c: Context) : LinearLayout(c) {
    private val name = TextView(c)
    private val bar = SegBar(c)
    private val left = TextView(c)
    private val right = TextView(c)

    init {
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
        name.setTextColor(TEXT)
        name.textSize = 15f
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.MIDDLE
        name.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        for (v in listOf(left, right)) {
            v.setTextColor(MUTED)
            v.textSize = 12f
        }
        left.maxLines = 2
        right.gravity = Gravity.END
        val meta = LinearLayout(c)
        meta.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        meta.addView(right, LinearLayout.LayoutParams(-2, -2))
        addView(name)
        addView(bar, LinearLayout.LayoutParams(-1, dp(8)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        addView(meta)
    }

    private fun clock(s: Long) =
        if (s >= 3600) "${s / 3600} jam ${s % 3600 / 60} mnt" else String.format("%d:%02d", s / 60, s % 60)

    fun bind(t: Task) {
        val tot = t.total
        val dn = t.done
        fun fs(x: Long) = Formatter.formatFileSize(context, x)
        name.text = t.name
        bar.set(t)
        when (t.status) {
            RUNNING -> {
                left.text = if (tot > 0) "${fs(dn)} dari ${fs(tot)}" else fs(dn)
                val eta = if (t.speed > 0 && tot > 0) ", sisa " + clock((tot - dn) / t.speed) else ""
                right.text = if (t.speed > 0) fs(t.speed) + "/s" + eta else "Menghubungkan"
            }
            SAVING -> {
                left.text = "Menyimpan ke folder Download"
                right.text = ""
            }
            DONE -> {
                when (t.xs) {
                    1 -> {
                        val pct = if (t.xtotal > 0) t.xdone * 100 / t.xtotal else 0L
                        left.text = "Mengekstrak: $pct%"
                        right.text = if (t.xtotal > 0) "${fs(t.xdone)} dari ${fs(t.xtotal)}" else ""
                    }
                    2 -> {
                        left.text = "Selesai, diekstrak ke folder \"${t.xout}\""
                        right.text = "Ketuk untuk buka"
                    }
                    3 -> {
                        left.text = "Selesai, gagal mengekstrak: ${t.xerr}"
                        right.text = "Ketuk untuk buka"
                    }
                    else -> {
                        left.text = "Selesai, ${fs(tot)}"
                        right.text = "Ketuk untuk buka"
                    }
                }
            }
            FAILED -> {
                left.text = "Gagal: ${t.err}"
                right.text = "Ketuk untuk ulangi"
            }
            QUEUED -> {
                left.text = "Mengantre"
                right.text = "Ketuk untuk jeda"
            }
            WAITING -> {
                left.text = Engine.waitReason()
                right.text = "Lanjut otomatis"
            }
            else -> {
                val of = if (tot > 0) " dari ${fs(tot)}" else ""
                left.text = "Dijeda di ${fs(dn)}$of"
                right.text = "Ketuk untuk lanjut"
            }
        }
    }
}

class MainActivity : Activity() {
    private lateinit var adp: BaseAdapter
    private lateinit var speedTv: TextView
    private lateinit var empty: TextView
    private lateinit var catBtn: TextView
    private var shown: List<Task> = emptyList()
    private var query = ""
    private var filter = "Semua"
    private var notifAsked = false
    private var importTarget: EditText? = null
    private val filters = arrayOf("Semua", "Sedang jalan", "Selesai", "Video", "Musik", "Arsip", "APK", "Dokumen", "Lainnya")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun copy(label: String, text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Disalin")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Engine.init(this)
        window.statusBarColor = INK
        window.navigationBarColor = INK

        speedTv = TextView(this).apply {
            setTextColor(TEAL)
            textSize = 13f
        }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(6))
            addView(TextView(context).apply {
                text = "Mister DM"
                textSize = 24f
                setTextColor(TEXT)
                typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(speedTv)
            addView(TextView(context).apply {
                text = "Pengaturan"
                textSize = 13f
                setTextColor(MUTED)
                setPadding(dp(16), dp(6), 0, dp(6))
                setOnClickListener { showSettings() }
            })
        }

        val search = EditText(this).apply {
            hint = "Cari unduhan"
            setHintTextColor(MUTED)
            setTextColor(TEXT)
            textSize = 14f
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim() ?: ""
                    refresh()
                }

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
        catBtn = TextView(this).apply {
            text = "Semua ▾"
            textSize = 13f
            setTextColor(TEAL)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { pickFilter() }
        }
        val clearBtn = TextView(this).apply {
            text = "Bersihkan"
            textSize = 13f
            setTextColor(MUTED)
            setPadding(dp(8), dp(8), dp(12), dp(8))
            setOnClickListener { confirmClear() }
        }
        val filterRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(6), dp(6))
            addView(search, LinearLayout.LayoutParams(0, -2, 1f))
            addView(catBtn)
            addView(clearBtn)
        }

        adp = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int): Any = shown[p]
            override fun getItemId(p: Int) = shown[p].id
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = cv as? Row ?: Row(this@MainActivity)
                row.bind(shown[p])
                return row
            }
        }
        val list = ListView(this).apply {
            adapter = adp
            divider = ColorDrawable(TRACK)
            dividerHeight = 1
            setOnItemClickListener { _, _, p, _ -> tap(shown.getOrNull(p)) }
            setOnItemLongClickListener { _, _, p, _ ->
                menu(shown.getOrNull(p))
                true
            }
        }
        empty = TextView(this).apply {
            text = ""
            setTextColor(MUTED)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
        }
        list.emptyView = empty
        val fab = TextView(this).apply {
            text = "+"
            textSize = 30f
            setTextColor(INK)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            elevation = dp(6).toFloat()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(TEAL)
            }
            setOnClickListener { showAdd(null) }
        }
        val frame = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(20), dp(24))
            })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(INK)
            addView(head)
            addView(filterRow)
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        })

        if (!Environment.isExternalStorageManager() && !Engine.askedStorage) storageDialog() else askNotif()
        if (b == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        Engine.onChange = { runOnUiThread { refresh() } }
        refresh()
        if (Engine.askedStorage || Environment.isExternalStorageManager()) askNotif()
    }

    override fun onPause() {
        super.onPause()
        Engine.onChange = null
    }

    // ---------- daftar, filter, pencarian ----------

    private fun cat(t: Task): String {
        return when (t.name.substringAfterLast('.', "").lowercase()) {
            "mp4", "mkv", "webm", "avi", "mov", "ts", "3gp", "flv", "m4v" -> "Video"
            "mp3", "m4a", "flac", "wav", "ogg", "aac", "opus" -> "Musik"
            "zip", "7z", "rar", "tar", "gz", "xz", "bz2", "iso" -> "Arsip"
            "apk", "apks", "xapk", "aab" -> "APK"
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv" -> "Dokumen"
            else -> "Lainnya"
        }
    }

    private fun match(t: Task): Boolean {
        if (query.isNotEmpty() && !t.name.contains(query, true)) return false
        return when (filter) {
            "Semua" -> true
            "Sedang jalan" -> t.status != DONE && t.status != PAUSED && t.status != FAILED
            "Selesai" -> t.status == DONE
            else -> cat(t) == filter
        }
    }

    private fun refresh() {
        shown = Engine.tasks.filter { match(it) }
        adp.notifyDataSetChanged()
        empty.text = if (Engine.tasks.isEmpty()) {
            "Belum ada unduhan.\nKetuk + untuk menempel link, atau bagikan link dari browser ke Mister DM."
        } else {
            "Tidak ada unduhan yang cocok dengan pencarian atau filter."
        }
        val sp = Engine.tasks.filter { it.status == RUNNING }.sumOf { it.speed }
        speedTv.text = if (sp > 0) Formatter.formatFileSize(this, sp) + "/s" else ""
    }

    private fun pickFilter() {
        AlertDialog.Builder(this).setTitle("Tampilkan").setItems(filters) { _, i ->
            filter = filters[i]
            catBtn.text = filter + " ▾"
            refresh()
        }.show()
    }

    private fun confirmClear() {
        val n = Engine.tasks.count { it.status == DONE }
        if (n == 0) {
            toast("Tidak ada unduhan selesai di daftar")
            return
        }
        AlertDialog.Builder(this).setTitle("Bersihkan daftar")
            .setMessage("Hapus $n unduhan selesai dari daftar? File-nya tetap ada.")
            .setPositiveButton("Hapus") { _, _ -> Engine.clearDone() }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- izin ----------

    private fun askNotif() {
        if (notifAsked) return
        notifAsked = true
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun askStorage() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (e2: Exception) {
                toast("Buka Pengaturan > Aplikasi > Mister DM > Izin untuk mengaktifkan akses semua file")
            }
        }
    }

    private fun storageDialog() {
        AlertDialog.Builder(this).setTitle("Izin akses semua file")
            .setMessage(
                "Aktifkan \"Akses semua file\" agar unduhan langsung tersimpan di folder Download tanpa disalin lagi " +
                    "(hemat ruang dan waktu) dan agar arsip bisa diekstrak. Tanpa izin ini, file disalin dulu di akhir " +
                    "sehingga butuh ruang dua kali lipat."
            )
            .setPositiveButton("Buka pengaturan") { _, _ -> askStorage() }
            .setNegativeButton("Nanti") { _, _ -> askNotif() }
            .setOnDismissListener { Engine.askedStorage = true }
            .show()
    }

    // ---------- pengaturan ----------

    private fun showSettings() {
        fun label(s: String) = TextView(this).apply {
            text = s
            setTextColor(MUTED)
            textSize = 12f
            setPadding(0, dp(14), 0, 0)
        }

        fun spin(items: Array<String>, sel: Int) = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
        }

        fun sw(txt: String, on: Boolean) = Switch(this).apply {
            text = txt
            isChecked = on
            setTextColor(TEXT)
            setPadding(0, dp(14), 0, dp(2))
        }

        val connItems = arrayOf("1", "2", "4", "8", "16")
        val parItems = arrayOf("1", "2", "3", "4", "5")
        val limItems = arrayOf("Tanpa batas", "1 MB/s", "2 MB/s", "5 MB/s", "10 MB/s", "20 MB/s")
        val limVals = intArrayOf(0, 1, 2, 5, 10, 20)
        val hours = Array(24) { String.format("%02d:00", it) }

        val sc = spin(connItems, connItems.indexOf(Engine.connsDefault.toString()).coerceAtLeast(0))
        val sp = spin(parItems, (Engine.maxParallel - 1).coerceIn(0, 4))
        val sl = spin(limItems, limVals.indexOf(Engine.speedLimit).coerceAtLeast(0))
        val wifi = sw("Hanya lewat Wi-Fi / jaringan tanpa kuota", Engine.wifiOnly)
        val auto = sw("Ekstrak ZIP/7z otomatis setelah selesai", Engine.autoExtract)
        val sch = sw("Jadwal unduh (di luar jam ini menunggu)", Engine.schedOn)
        val sf = spin(hours, Engine.schedFrom.coerceIn(0, 23))
        val st = spin(hours, Engine.schedTo.coerceIn(0, 23))
        val granted = Environment.isExternalStorageManager()
        val perm = TextView(this).apply {
            text = if (granted) "Akses semua file: aktif" else "Akses semua file: belum aktif. Ketuk untuk mengaktifkan (hemat ruang, ekstrak arsip)."
            setTextColor(if (granted) TEAL else AMBER)
            textSize = 13f
            setPadding(0, dp(16), 0, dp(8))
            setOnClickListener { askStorage() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(label("Koneksi per file (bawaan)"))
            addView(sc)
            addView(label("Unduhan bersamaan"))
            addView(sp)
            addView(label("Batas kecepatan"))
            addView(sl)
            addView(wifi)
            addView(auto)
            addView(sch)
            addView(label("Jadwal: mulai jam"))
            addView(sf)
            addView(label("Jadwal: selesai jam"))
            addView(st)
            addView(perm)
        }
        AlertDialog.Builder(this).setTitle("Pengaturan")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Simpan") { _, _ ->
                Engine.connsDefault = connItems[sc.selectedItemPosition].toInt()
                Engine.maxParallel = parItems[sp.selectedItemPosition].toInt()
                Engine.speedLimit = limVals[sl.selectedItemPosition]
                Engine.autoExtract = auto.isChecked
                Engine.schedFrom = sf.selectedItemPosition
                Engine.schedTo = st.selectedItemPosition
                Engine.schedOn = sch.isChecked
                Engine.wifiOnly = wifi.isChecked
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- tambah unduhan ----------

    /** Link yang dibagikan dari browser (Bagikan > Mister DM) membuka dialog tambah. */
    private fun handle(i: Intent?) {
        val a = i ?: return
        if (a.action != Intent.ACTION_SEND) return
        val m = Regex("(?:https?://|magnet:)\\S+").find(a.getStringExtra(Intent.EXTRA_TEXT) ?: "") ?: return
        showAdd(m.value)
    }

    private fun clip(): String = try {
        val c = getSystemService(ClipboardManager::class.java).primaryClip
        val s = if (c != null && c.itemCount > 0) c.getItemAt(0).text?.toString()?.trim() else null
        if (s != null && Regex("(?i)(?:https?://|magnet:)\\S+").matches(s)) s else ""
    } catch (e: Exception) {
        ""
    }

    private fun showAdd(pre: String?) {
        val et = EditText(this).apply {
            hint = "Tempel link (boleh banyak, satu per baris)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 6
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            setText(pre ?: clip())
        }
        val connItems = arrayOf("1", "2", "4", "8", "16")
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, connItems)
            setSelection(connItems.indexOf(Engine.connsDefault.toString()).coerceAtLeast(0))
        }
        val imp = TextView(this).apply {
            text = "Impor daftar link dari file .txt"
            setTextColor(TEAL)
            textSize = 13f
            setPadding(0, dp(16), 0, dp(6))
            setOnClickListener {
                importTarget = et
                pickTxt()
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(et)
            addView(TextView(context).apply {
                text = "Koneksi per file"
                setTextColor(MUTED)
                textSize = 12f
                setPadding(0, dp(14), 0, 0)
            })
            addView(sp)
            addView(imp)
        }
        AlertDialog.Builder(this).setTitle("Tambah unduhan").setView(box)
            .setPositiveButton("Unduh") { _, _ -> submit(et.text.toString(), connItems[sp.selectedItemPosition].toInt()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun submit(text: String, n: Int) {
        val links = Regex("(?:https?://|magnet:)\\S+", RegexOption.IGNORE_CASE).findAll(text).map { it.value }.toList()
        if (links.isEmpty()) {
            val raw = text.trim()
            if (raw.isEmpty() || raw.contains(' ') || raw.contains('\n') || !raw.contains('.')) {
                toast("Link tidak valid. Mulai dengan http:// atau https://")
            } else {
                submit("https://" + raw, n)
            }
            return
        }
        if (links.size == 1) {
            single(links[0], n)
            return
        }
        var added = 0
        var skipped = 0
        for (l in links) {
            if (l.startsWith("magnet:", true) || l.substringBefore('?').endsWith(".torrent", true)) {
                skipped++
                continue
            }
            val hls = l.substringBefore('?').lowercase().endsWith(".m3u8")
            Engine.add(l, n, if (hls) K_HLS else K_FILE)
            added++
        }
        toast("$added link ditambahkan" + (if (skipped > 0) ", $skipped magnet/torrent dilewati" else ""))
    }

    private fun single(u: String, n: Int) {
        if (u.startsWith("magnet:", true) || u.substringBefore('?').endsWith(".torrent", true)) {
            torrent(u)
            return
        }
        toast("Memeriksa link…")
        Engine.resolve(u) { kind, urls -> found(u, n, kind, urls) }
    }

    private fun found(u: String, n: Int, kind: Int, urls: List<String>) {
        if (kind != K_PAGE) {
            Engine.add(u, n, kind)
            return
        }
        if (urls.isEmpty()) {
            toast("Tidak ada video atau file yang ditemukan di halaman ini")
            return
        }
        val names = urls.map { link -> link.substringBefore('?').substringAfterLast('/').ifEmpty { link } }
        AlertDialog.Builder(this).setTitle("Ditemukan di halaman")
            .setItems(names.toTypedArray()) { _, i ->
                val pu = urls[i]
                val hls = pu.substringBefore('?').lowercase().endsWith(".m3u8")
                Engine.add(pu, n, if (hls) K_HLS else K_FILE)
            }
            .show()
    }

    /** Mesin torrent bawaan belum ada: teruskan magnet / .torrent ke aplikasi torrent yang terpasang. */
    private fun torrent(u: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
            if (!u.startsWith("magnet:", true)) i.setDataAndType(Uri.parse(u), "application/x-bittorrent")
            startActivity(i)
        } catch (e: Exception) {
            toast("Belum ada aplikasi torrent terpasang. Pasang satu dulu, lalu coba lagi.")
        }
    }

    private fun pickTxt() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/*")
        try {
            startActivityForResult(i, 7)
        } catch (e: Exception) {
            toast("Tidak bisa membuka pemilih file")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try {
            val txt = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
            importTarget?.setText(txt.take(200000))
        } catch (e: Exception) {
            toast("Gagal membaca file")
        }
    }

    // ---------- aksi pada unduhan ----------

    private fun tap(t: Task?) {
        if (t == null) return
        when (t.status) {
            DONE -> open(t)
            RUNNING, QUEUED, WAITING -> Engine.pause(t)
            SAVING -> {}
            else -> Engine.start(t)
        }
    }

    private fun menu(t: Task?) {
        if (t == null) return
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun item(l: String, a: () -> Unit) {
            labels.add(l)
            acts.add(a)
        }
        item("Salin link") { copy("url", t.url) }
        if (t.status != DONE) item("Ganti link") { changeLink(t) }
        if (t.status == DONE) {
            item("Hitung checksum") { showChecksum(t) }
            if (Extractor.can(t.name)) {
                item("Ekstrak sekarang") {
                    val m = Extractor.start(t)
                    if (m != null) toast(m)
                }
            }
        }
        item("Hapus dari daftar") { Engine.remove(t, false) }
        if (t.status == DONE) item("Hapus beserta file") { Engine.remove(t, true) }
        AlertDialog.Builder(this).setTitle(t.name)
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun changeLink(t: Task) {
        val et = EditText(this).apply {
            setText(t.src.ifEmpty { t.url })
            setTextColor(TEXT)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this).setTitle("Ganti link")
            .setMessage("Tempel link baru untuk file yang sama. Unduhan dilanjutkan dari bagian terakhir.")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                toast("Memeriksa link…")
                Engine.refreshLink(t, et.text.toString()) { err -> toast(err ?: "Link diganti, melanjutkan unduhan") }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showChecksum(t: Task) {
        val cancel = AtomicBoolean(false)
        val dlg = AlertDialog.Builder(this).setTitle("Checksum").setMessage("Menghitung… 0%")
            .setNegativeButton("Batal", null)
            .setOnDismissListener { cancel.set(true) }
            .show()
        Engine.pool.execute {
            try {
                val ins: InputStream = if (t.direct) {
                    FileInputStream(File(t.path))
                } else {
                    contentResolver.openInputStream(Uri.parse(t.uri)) ?: throw IOException("File tidak ditemukan")
                }
                val md5 = MessageDigest.getInstance("MD5")
                val sha = MessageDigest.getInstance("SHA-256")
                val total = maxOf(t.total, 1L)
                var read = 0L
                var last = 0L
                ins.use { s ->
                    val buf = ByteArray(1 shl 20)
                    while (!cancel.get()) {
                        val n = s.read(buf)
                        if (n < 0) break
                        md5.update(buf, 0, n)
                        sha.update(buf, 0, n)
                        read += n
                        val now = System.currentTimeMillis()
                        if (now - last > 700) {
                            last = now
                            val pct = read * 100 / total
                            runOnUiThread { dlg.setMessage("Menghitung… $pct%") }
                        }
                    }
                }
                if (!cancel.get()) {
                    val m = hex(md5.digest())
                    val s2 = hex(sha.digest())
                    runOnUiThread { checksumResult(t, m, s2, dlg) }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlg.dismiss()
                    toast("Gagal menghitung checksum: " + e.message)
                }
            }
        }
    }

    private fun checksumResult(t: Task, md5: String, sha: String, old: AlertDialog) {
        old.dismiss()
        val tv = TextView(this).apply {
            text = "MD5\n$md5\n\nSHA-256\n$sha"
            setTextColor(TEXT)
            textSize = 12f
            setTextIsSelectable(true)
        }
        val et = EditText(this).apply {
            hint = "Tempel checksum dari situs untuk dicocokkan"
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            isSingleLine = true
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(tv)
            addView(et)
        }
        AlertDialog.Builder(this).setTitle(t.name).setView(box)
            .setPositiveButton("Cocokkan") { _, _ ->
                val want = et.text.toString().trim().lowercase()
                toast(
                    if (want.isEmpty()) "Tempel checksum dulu"
                    else if (want == md5 || want == sha) "Cocok: file utuh"
                    else "TIDAK cocok: file rusak atau berbeda"
                )
            }
            .setNeutralButton("Salin SHA-256") { _, _ -> copy("SHA-256", sha) }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun open(t: Task) {
        try {
            val ext = t.name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val u = if (t.direct) FileProvider.getUriForFile(this, "app.misterdm.files", File(t.path)) else Uri.parse(t.uri)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            toast("Tidak ada aplikasi yang bisa membuka file ini, atau file sudah dihapus")
        }
    }
}
