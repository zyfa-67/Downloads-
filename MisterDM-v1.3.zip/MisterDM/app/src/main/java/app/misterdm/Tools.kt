package app.misterdm

import android.os.StatFs
import android.util.Base64
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import java.net.URLEncoder
import java.util.zip.ZipFile

/** Pembatas kecepatan global (byte/detik, 0 = tanpa batas). */
object Limiter {
    @Volatile var rate = 0L
    private var next = 0L

    fun take(n: Int) {
        val r = rate
        if (r <= 0L) return
        var wait = 0L
        synchronized(this) {
            val now = System.nanoTime()
            if (next < now - 250000000L) next = now - 250000000L
            next += n * 1000000000L / r
            wait = next - now
        }
        if (wait > 0L) {
            try {
                Thread.sleep(wait / 1000000L, (wait % 1000000L).toInt())
            } catch (e: InterruptedException) { }
        }
    }
}

/** Ubah link halaman hoster populer jadi link unduhan langsung (upaya terbaik; situs bisa berubah kapan saja). */
object Hosts {
    fun supports(url: String): Boolean {
        val h = try {
            URL(url).host.lowercase()
        } catch (e: Exception) {
            return false
        }
        return h == "www.mediafire.com" || h == "mediafire.com" || h == "drive.google.com" || h.endsWith("dropbox.com")
    }

    fun direct(src: String): String {
        val h = URL(src).host.lowercase()
        return when {
            h.endsWith("dropbox.com") -> dropbox(src)
            h == "drive.google.com" -> drive(src)
            else -> mediafire(src)
        }
    }

    private fun page(url: String): String =
        Engine.client.newCall(Engine.req(url)).execute().use { r ->
            if (!r.isSuccessful) throw HttpErr(r.code)
            r.peekBody(1500000).string()
        }

    private fun dropbox(src: String): String {
        val u = src.replace(Regex("([?&])dl=0"), "\$1dl=1")
        return if (u.contains("dl=1")) u else u + (if (u.contains("?")) "&" else "?") + "dl=1"
    }

    private fun mediafire(src: String): String {
        if (src.contains("/folder/")) throw IOException("Link folder MediaFire belum didukung")
        val html = page(src)
        val scr = Regex("data-scrambled-url=\"([^\"]+)\"").find(html)
        if (scr != null) {
            return String(Base64.decode(scr.groupValues[1], Base64.DEFAULT))
        }
        val m = Regex("https?://download[0-9a-z-]*\\.mediafire\\.com/[^\"'\\s<>\\\\]+").find(html)
        if (m != null) return m.value.replace("&amp;", "&")
        throw IOException("Link unduhan MediaFire tidak ditemukan (file dihapus atau halaman berubah)")
    }

    private fun drive(src: String): String {
        if (src.contains("/folders/")) throw IOException("Link folder Google Drive belum didukung")
        val id = Regex("/d/([A-Za-z0-9_-]{10,})").find(src)?.groupValues?.get(1)
            ?: Regex("[?&]id=([A-Za-z0-9_-]{10,})").find(src)?.groupValues?.get(1)
            ?: throw IOException("ID file Google Drive tidak ditemukan di link")
        val first = "https://drive.google.com/uc?export=download&id=" + id
        return Engine.client.newCall(Engine.req(first)).execute().use { r ->
            if (!r.isSuccessful) throw HttpErr(r.code)
            val ct = (r.header("Content-Type") ?: "").lowercase()
            if (r.header("Content-Disposition") != null || !ct.startsWith("text/html")) {
                first
            } else {
                val html = r.peekBody(600000).string()
                val form = Regex("<form[^>]*id=\"download-form\"[^>]*action=\"([^\"]+)\"").find(html)
                    ?: throw IOException("File Google Drive tidak publik atau kuota unduhan sudah habis")
                val params = Regex("<input[^>]+>").findAll(html).mapNotNull { m ->
                    val tag = m.value
                    val n = Regex("name=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
                    val v = Regex("value=\"([^\"]*)\"").find(tag)?.groupValues?.get(1) ?: ""
                    if (n == null) null else n + "=" + URLEncoder.encode(v.replace("&amp;", "&"), "UTF-8")
                }.joinToString("&")
                form.groupValues[1].replace("&amp;", "&") + "?" + params
            }
        }
    }
}

/** Ekstrak ZIP dan 7z ke folder di samping arsipnya (butuh izin "akses semua file"). */
object Extractor {
    fun can(name: String): Boolean {
        val e = name.substringAfterLast('.', "").lowercase()
        return e == "zip" || e == "7z"
    }

    /** Mulai ekstrak di latar belakang. Mengembalikan pesan kalau tidak bisa dimulai. */
    fun start(t: Task): String? {
        if (t.status != DONE || !can(t.name)) return "Bukan arsip ZIP atau 7z"
        if (!t.direct) return "Butuh izin \"Akses semua file\" untuk mengekstrak"
        if (t.xs == 1) return "Sedang mengekstrak"
        t.xs = 1
        t.xdone = 0L
        t.xtotal = 0L
        t.xerr = ""
        t.xout = ""
        Engine.poke()
        Engine.pool.execute {
            try {
                extract(t)
            } catch (e: PasswordRequiredException) {
                t.xs = 3
                t.xerr = "arsip berpassword belum didukung"
            } catch (e: OutOfMemoryError) {
                t.xs = 3
                t.xerr = "memori tidak cukup"
            } catch (e: Exception) {
                t.xs = 3
                t.xerr = e.message ?: e.javaClass.simpleName
            } finally {
                Engine.poke()
                Engine.save()
            }
        }
        return null
    }

    private fun extract(t: Task) {
        val src = File(t.path)
        val parent = src.parentFile ?: throw IOException("Folder tidak ditemukan")
        val out = File(parent, Engine.uniq(parent, t.name.substringBeforeLast('.', t.name)))
        out.mkdirs()
        try {
            if (t.name.substringAfterLast('.', "").lowercase() == "zip") zip(t, src, out) else sevenZ(t, src, out)
        } catch (e: Throwable) {
            out.deleteRecursively()
            throw e
        }
        if (t.removed) {
            out.deleteRecursively()
            return
        }
        t.xout = out.name
        t.xs = 2
    }

    private fun need(dir: File, bytes: Long) {
        val free = StatFs(dir.path).availableBytes
        if (free < bytes + 64L * 1024 * 1024) {
            throw IOException("ruang tidak cukup (butuh ${bytes / 1048576} MB, tersedia ${free / 1048576} MB)")
        }
    }

    private fun zip(t: Task, src: File, out: File) {
        val zf = try {
            ZipFile(src)
        } catch (e: IllegalArgumentException) {
            ZipFile(src, Charsets.ISO_8859_1)
        }
        zf.use { z ->
            val entries = z.entries().toList()
            t.xtotal = entries.sumOf { if (it.isDirectory) 0L else maxOf(it.size, 0L) }
            need(out, t.xtotal)
            val root = out.canonicalPath + File.separator
            val buf = ByteArray(256 * 1024)
            for (e in entries) {
                if (t.removed) return
                val name = e.name.replace('\\', '/')
                val f = File(out, name)
                if (!f.canonicalPath.startsWith(root)) throw IOException("arsip tidak aman: " + name)
                if (e.isDirectory) {
                    f.mkdirs()
                    continue
                }
                f.parentFile?.mkdirs()
                z.getInputStream(e).use { ins ->
                    FileOutputStream(f).use { os ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                            t.xdone += n
                        }
                    }
                }
            }
        }
    }

    private fun sevenZ(t: Task, src: File, out: File) {
        SevenZFile(src).use { z ->
            t.xtotal = z.entries.sumOf { if (it.isDirectory) 0L else maxOf(it.size, 0L) }
            need(out, t.xtotal)
            val root = out.canonicalPath + File.separator
            val buf = ByteArray(256 * 1024)
            var e = z.nextEntry
            while (e != null) {
                if (t.removed) return
                val name = (e.name ?: "file").replace('\\', '/')
                val f = File(out, name)
                if (!f.canonicalPath.startsWith(root)) throw IOException("arsip tidak aman: " + name)
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { os ->
                        while (true) {
                            val n = z.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                            t.xdone += n
                        }
                    }
                }
                e = z.nextEntry
            }
        }
    }
}
